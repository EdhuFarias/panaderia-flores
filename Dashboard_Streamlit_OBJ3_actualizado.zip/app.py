"""
PANADERÍA – OBJETIVO 3 | 5S + Gestión visual (codificación de los 9 productos)
Dashboard en Streamlit (AS-IS septiembre 2026 vs. TO-BE octubre 2026).

Ejecutar en tu computadora:
    pip install -r requirements.txt
    streamlit run app.py

El archivo Datos_PowerBI_OBJ3.xlsx debe estar en la misma carpeta que app.py.
"""
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ---------------------------------------------------------------- configuración
st.set_page_config(page_title="Panadería · Objetivo 3 · 5S + Gestión visual", page_icon="🥖", layout="wide")
DATA = Path(__file__).parent / "Datos_PowerBI_OBJ3.xlsx"

ROJO, AZUL, VERDE, DORADO, GRIS = "#F26B6B", "#3B82F6", "#34D399", "#FBBF24", "#9CA3AF"
C_ASIS, C_TOBE = "#F26B6B", "#34D399"
PLOT = dict(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(family="Segoe UI, Roboto, sans-serif", size=12), margin=dict(l=10, r=10, t=45, b=10))

st.markdown("""
<style>
.block-container {padding-top: 1.2rem;}
.hero {background: linear-gradient(90deg,#1e293b 0%,#334155 55%,#7c4a2d 100%); border:1px solid #475569;
       border-radius:14px; padding:22px 26px; margin-bottom:18px;}
.hero h1 {margin:0; font-size:2.0rem; color:#fff;}
.hero p {margin:4px 0 0 0; color:#cbd5e1;}
.kpi {background:#1e293b; border:1px solid #334155; border-radius:12px; padding:14px 16px; height:100%;}
.kpi .t {color:#94a3b8; font-size:.78rem; font-weight:600; text-transform:uppercase; letter-spacing:.4px;}
.kpi .v {color:#fff; font-size:1.9rem; font-weight:700; margin:2px 0;}
.kpi .s {color:#cbd5e1; font-size:.80rem;}
.ok {background:#064e3b; color:#6ee7b7; padding:2px 8px; border-radius:6px; font-size:.75rem; font-weight:700;}
.pr {background:#78350f; color:#fcd34d; padding:2px 8px; border-radius:6px; font-size:.75rem; font-weight:700;}
.box {background:#1e293b; border:1px solid #334155; border-radius:12px; padding:14px 18px; margin-bottom:10px;}
.box b {color:#fbbf24;}
.prod {border-radius:10px; padding:12px; color:#111827; margin-bottom:10px; min-height:120px;}
.prod .c {font-size:1.3rem; font-weight:800;}
.small {color:#94a3b8; font-size:.8rem;}
</style>""", unsafe_allow_html=True)


# ---------------------------------------------------------------- datos
@st.cache_data
def cargar():
    return pd.read_excel(DATA, sheet_name=None)


try:
    D = cargar()
except FileNotFoundError:
    st.error("No encuentro 'Datos_PowerBI_OBJ3.xlsx'. Ponlo en la misma carpeta que app.py.")
    st.stop()

MEN = D["Mensual"]
DIA = D["Diario"]
PROD = D["Productos"]
SEM = D["Semanal"]
IND = D["Indicadores"].set_index("Orden")
INV = D["Inversion"]
CAP = D["Capacitacion"]
ECO = dict(zip(D["Economia"]["Concepto"], D["Economia"]["Valor"]))

HEX = {"Azul": "#BDD7EE", "Verde": "#C6EFCE", "Amarillo": "#FFEB9C", "Naranja": "#F8CBAD", "Morado": "#D9C3E9",
       "Rosado": "#F4CCCC", "Turquesa": "#B7E4E0", "Café": "#E2CBB0", "Gris": "#D9D9D9"}
PROD["Hex"] = PROD["Color"].map(HEX).fillna("#D9D9D9")
ANTES = {"CI-01": "En vitrina, mezclado y sin etiqueta", "FR-02": "En la misma canasta que el pan de yema",
         "EM-03": "Junto al pan, sin separación", "PY-04": "Tirado en la canasta del pan francés",
         "PI-05": "Bolsas sueltas sobre el mostrador", "CA-06": "Bandeja encima de la caja",
         "TO-07": "Bolsas tiradas sobre la harina", "PM-08": "Tiradas junto a las tostadas",
         "KE-09": "Táper abierto, sin precio"}
PLAN_5S = [
    ("SEIRI · Clasificar", "Semana 1",
     "11 tarjetas rojas a lo que no se vende (48 elementos retirados o reubicados) y se recogen los 6 productos que "
     "estaban tirados."),
    ("SEITON · Ordenar", "Semanas 1–2",
     "Código, color y lugar fijo para los 9 productos: vitrina 1 (CI-01, FR-02, EM-03), vitrina 2 (PY-04, PI-05, "
     "CA-06), estante (TO-07, PM-08) y campana del mostrador (KE-09)."),
    ("SEISO · Limpiar", "Semana 2", "Limpieza al abrir y cerrar; nada en el piso ni sobre la harina; etiquetas legibles."),
    ("SEIKETSU · Estandarizar", "Semana 3",
     "Regla 'código en vitrina = código en Excel' y un formato único de registro en el celular del negocio."),
    ("SHITSUKE · Disciplina", "Semana 4 en adelante",
     "9 sesiones de capacitación, registrar al despachar, cuadre diario al cierre y revisión semanal del orden."),
]

ASIS = DIA[DIA["Escenario"].str.startswith("AS-IS")].reset_index(drop=True)
TOBE = DIA[DIA["Escenario"].str.startswith("TO-BE")].reset_index(drop=True)


def cumple(r):
    return r["TO_BE"] >= r["Meta"] if r["Mayor_es_mejor"] == "Sí" else r["TO_BE"] <= r["Meta"]


def kpi(col, titulo, valor, sub, ok=None):
    tag = "" if ok is None else (' <span class="ok">CUMPLE</span>' if ok else ' <span class="pr">EN PROCESO</span>')
    col.markdown(f'<div class="kpi"><div class="t">{titulo}</div><div class="v">{valor}</div>'
                 f'<div class="s">{sub}{tag}</div></div>', unsafe_allow_html=True)


def soles(x, d=2):
    return f"S/ {x:,.{d}f}"


i1, i2, i3, i4 = IND.loc[1], IND.loc[2], IND.loc[3], IND.loc[4]

# ---------------------------------------------------------------- encabezado
st.markdown("""<div class="hero"><h1>🥖 Panadería · Objetivo 3 · 5S + Gestión visual</h1>
<p>Codificación de los 9 productos para registrar cada venta · AS-IS septiembre 2026 (datos reales) vs.
TO-BE octubre 2026 (simulado con la mejora) · Ciclo PHVA</p></div>""", unsafe_allow_html=True)

c = st.columns(4)
kpi(c[0], "IND 1 · % productos con código", f"{i1['TO_BE']:.1%}",
    f"AS-IS {i1['AS_IS']:.0%} · Meta {i1['Meta']:.0%}", cumple(i1))
kpi(c[1], "IND 2 · % ventas registradas", f"{i2['TO_BE']:.1%}",
    f"AS-IS {i2['AS_IS']:.1%} · Meta {i2['Meta']:.1%}", cumple(i2))
kpi(c[2], "Ventas no registradas / mes", soles(i3["TO_BE"]),
    f"AS-IS {soles(i3['AS_IS'])} · Meta {soles(i3['Meta'])}", cumple(i3))
kpi(c[3], "Días sin ningún registro", f"{int(i4['TO_BE'])}",
    f"AS-IS {int(i4['AS_IS'])} · Meta {int(i4['Meta'])}", cumple(i4))
st.write("")

t1, t2, t3, t4, t5 = st.tabs(["📌 Resumen", "🔎 Planear: problema y AS-IS", "🛠️ Hacer: 5S + gestión visual",
                              "📈 Verificar: TO-BE", "💰 Actuar: impacto económico"])

# ================================================================ 1. RESUMEN
with t1:
    a, b = st.columns([1.1, 1])
    with a:
        st.markdown("""<div class="box"><b>Motivo:</b> falta de conciliación entre ventas físicas y registros.<br>
<b>Causa raíz:</b> falta de codificación de los productos y de formatos de control para anotar las salidas diarias.<br>
<b>Objetivo:</b> implementar la codificación de los productos y un formato estándar de registro diario.<br>
<b>Indicador principal (IND 1):</b> % de productos registrados con su código en el día (promedio del mes).<br>
<b>Indicador de efecto (IND 2):</b> % de ventas registradas en soles.<br>
<b>Herramientas:</b> 5S (ordenar y codificar) + gestión visual (colores, etiquetas, lista de códigos y tablero con semáforo).</div>""",
                    unsafe_allow_html=True)
        tabla = pd.DataFrame({
            "Indicador": ["IND 1: % productos con código", "IND 2: % ventas registradas",
                          "Ventas no registradas / mes", "Días sin registro"],
            "AS-IS (sep)": [f"{i1['AS_IS']:.1%}", f"{i2['AS_IS']:.1%}", soles(i3["AS_IS"]), int(i4["AS_IS"])],
            "TO-BE (oct)": [f"{i1['TO_BE']:.1%}", f"{i2['TO_BE']:.1%}", soles(i3["TO_BE"]), int(i4["TO_BE"])],
            "Meta": [f"{i1['Meta']:.0%}", f"{i2['Meta']:.1%}", soles(i3["Meta"]), int(i4["Meta"])],
            "Estado": [IND.loc[k, "Estado"] for k in (1, 2, 3, 4)],
        })
        st.dataframe(tabla, hide_index=True, use_container_width=True)
    with b:
        fig = go.Figure()
        cats = ["IND 1 · % con código", "IND 2 · % registrado"]
        fig.add_bar(name="AS-IS (sep)", x=cats, y=[i1["AS_IS"], i2["AS_IS"]], marker_color=C_ASIS,
                    text=[f"{i1['AS_IS']:.0%}", f"{i2['AS_IS']:.1%}"], textposition="outside")
        fig.add_bar(name="TO-BE (oct)", x=cats, y=[i1["TO_BE"], i2["TO_BE"]], marker_color=C_TOBE,
                    text=[f"{i1['TO_BE']:.1%}", f"{i2['TO_BE']:.1%}"], textposition="outside")
        fig.add_scatter(name="Meta", x=cats, y=[i1["Meta"], i2["Meta"]], mode="markers",
                        marker=dict(symbol="line-ew-open", size=60, color=DORADO, line=dict(width=4)))
        fig.update_layout(**PLOT, height=380, barmode="group", title="Antes vs. después vs. meta",
                          yaxis=dict(tickformat=".0%", range=[0, 1.1]), legend=dict(orientation="h", y=-0.15))
        st.plotly_chart(fig, use_container_width=True)
    st.caption("Metas: Araujo y Alva (2025), Universidad de Lima — una panificadora con 5S llegó a 80.56 % de exactitud de "
               "registro (meta IND 1 = 80 %); la meta del IND 2 aplica el mismo 25.1 % de cierre de brecha. "
               "El IND 1 queda 'en proceso' porque el encargado aún se está adaptando a los códigos.")

# ================================================================ 2. PLANEAR
with t2:
    a, b = st.columns(2)
    with a:
        m = MEN.copy()
        m["Etiqueta"] = pd.to_datetime(m["Mes"]).dt.strftime("%b %y")
        fig = px.line(m, x="Etiqueta", y="Pct_registrado", markers=True, title="Ventas registradas por mes (12 meses)")
        fig.update_traces(line_color=AZUL)
        fig.add_scatter(x=[m["Etiqueta"].iloc[-1]], y=[m["Pct_registrado"].iloc[-1]], mode="markers+text",
                        marker=dict(size=14, color=ROJO), text=["AS-IS"], textposition="top center", showlegend=False)
        fig.update_layout(**PLOT, height=360, yaxis_tickformat=".0%", xaxis_title=None, yaxis_title=None)
        st.plotly_chart(fig, use_container_width=True)
        tot = MEN["Ventas_registradas"].sum() / MEN["Ventas_realizadas"].sum()
        st.markdown(f"En 12 meses se registró el **{tot:.0%}** de las ventas y quedaron sin registrar "
                    f"**{soles(MEN['Perdida_S'].sum())}**. Se toma **septiembre 2026** como AS-IS (último mes medido).")
    with b:
        fig = px.bar(ASIS, x="Dia_mes", y="Pct_registrado", title="Septiembre (AS-IS): % registrado por día",
                     color=ASIS["Pct_registrado"].eq(0).map({True: "Día sin registro", False: "Con registro"}),
                     color_discrete_map={"Día sin registro": ROJO, "Con registro": GRIS})
        fig.update_layout(**PLOT, height=360, yaxis_tickformat=".0%", xaxis_title="Día del mes", yaxis_title=None,
                          legend_title=None, legend=dict(orientation="h", y=-0.2))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(f"Septiembre: **{int(ECO['Ventas_mes_ASIS']):,}** ventas, **{i2['AS_IS']:.0%}** registradas, "
                    f"**{soles(ECO['No_reg_mes_ASIS'])}** sin registrar, **0 de 9** productos con código y "
                    f"**{int(i4['AS_IS'])}** días sin ningún registro. La panadería no anota sus ventas: el panadero "
                    "las calcula “al ojo” al cierre.")
    st.markdown("#### Así estaban los productos antes")
    st.dataframe(pd.DataFrame({"Producto": PROD["Producto"], "Situación antes de la mejora": PROD["Codigo"].map(ANTES),
                               "¿Tenía código?": "No"}), hide_index=True, use_container_width=True)

# ================================================================ 3. HACER
with t3:
    st.markdown("#### Catálogo visual: código, color y lugar fijo (Seiton + gestión visual)")
    cols = st.columns(3)
    for k, r in PROD.iterrows():
        cols[k % 3].markdown(
            f'<div class="prod" style="background:{r["Hex"]}"><div class="c">{r["Codigo"]}</div>'
            f'<b>{r["Producto"]}</b> · S/ {r["Precio"]:.2f}<br>📍 {r["Ubicacion"]}<br>'
            f'<span style="font-size:.78rem">Antes: {ANTES.get(r["Codigo"], "")}</span></div>', unsafe_allow_html=True)
    a, b = st.columns([1.2, 1])
    with a:
        st.markdown("#### Plan por cada S")
        for s, cuando, que in PLAN_5S:
            st.markdown(f'<div class="box"><b>{s}</b> <span class="small">· {cuando}</span><br>{que}</div>',
                        unsafe_allow_html=True)
    with b:
        st.markdown("#### Tablero con semáforo (al cierre)")
        st.markdown('<div class="box">🟢 <b>VERDE</b>: ≥ 80 % de las ventas registradas<br>'
                    '🟡 <b>AMARILLO</b>: 60 % – 79 %<br>🔴 <b>ROJO</b>: menos de 60 % → se anota la causa y se '
                    'corrige al día siguiente</div>', unsafe_allow_html=True)
        sem = TOBE["Pct_registrado"].apply(lambda x: "Verde" if x >= .8 else ("Amarillo" if x >= .6 else "Rojo"))
        cnt = sem.value_counts().reindex(["Verde", "Amarillo", "Rojo"]).fillna(0)
        fig = px.pie(values=cnt.values, names=cnt.index, hole=.55, color=cnt.index,
                     color_discrete_map={"Verde": VERDE, "Amarillo": DORADO, "Rojo": ROJO},
                     title="Días de octubre por color del semáforo")
        fig.update_layout(**PLOT, height=300)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("#### Capacitación del encargado (9 sesiones)")
        st.dataframe(CAP[["Semana", "Fecha", "Tema", "Minutos"]], hide_index=True, use_container_width=True)

# ================================================================ 4. VERIFICAR
with t4:
    a, b = st.columns(2)
    with a:
        fig = go.Figure()
        fig.add_scatter(x=ASIS["Dia_mes"], y=ASIS["Pct_registrado"], name="AS-IS (sep)", line_color=C_ASIS)
        fig.add_scatter(x=TOBE["Dia_mes"], y=TOBE["Pct_registrado"], name="TO-BE (oct)", line_color=C_TOBE)
        fig.add_hline(y=i2["Meta"], line_dash="dot", line_color=DORADO, annotation_text=f"Meta {i2['Meta']:.1%}")
        fig.update_layout(**PLOT, height=360, title="% de ventas registradas por día",
                          yaxis_tickformat=".0%", xaxis_title="Día del mes", legend=dict(orientation="h", y=-0.2))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        fig = go.Figure()
        fig.add_bar(x=SEM["Semana"], y=SEM["Pct_registrado"], name="% ventas registradas", marker_color=AZUL,
                    text=[f"{v:.0%}" for v in SEM["Pct_registrado"]], textposition="outside")
        fig.add_bar(x=SEM["Semana"], y=SEM["Pct_uso_codigos"], name="% productos con código", marker_color=VERDE,
                    text=[f"{v:.0%}" for v in SEM["Pct_uso_codigos"]], textposition="outside")
        fig.update_layout(**PLOT, height=360, barmode="group", title="Curva de adaptación del encargado (octubre)",
                          yaxis=dict(tickformat=".0%", range=[0, 1.15]), legend=dict(orientation="h", y=-0.2))
        st.plotly_chart(fig, use_container_width=True)
    a, b = st.columns(2)
    with a:
        p = PROD.sort_values("Pct_uso_codigo_oct")
        fig = go.Figure(go.Bar(x=p["Pct_uso_codigo_oct"], y=p["Codigo"] + " " + p["Producto"], orientation="h",
                               marker_color=p["Hex"], marker_line=dict(color="#111827", width=1),
                               text=[f"{v:.0%}" for v in p["Pct_uso_codigo_oct"]], textposition="outside"))
        fig.add_vline(x=i1["Meta"], line_dash="dot", line_color=DORADO, annotation_text="Meta 80 %")
        fig.update_layout(**PLOT, height=400, title="Octubre: % de días en que cada producto se anotó con su código",
                          xaxis=dict(tickformat=".0%", range=[0, 1.05]))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        p = PROD.copy()
        p["% reg. sep"] = p["Registrado_sep"] / p["Venta_sep"]
        p["% reg. oct"] = p["Registrado_oct"] / p["Venta_oct"]
        fig = go.Figure()
        fig.add_bar(x=p["Codigo"], y=p["% reg. sep"], name="AS-IS (sep)", marker_color=C_ASIS)
        fig.add_bar(x=p["Codigo"], y=p["% reg. oct"], name="TO-BE (oct)", marker_color=C_TOBE)
        fig.update_layout(**PLOT, height=400, barmode="group", title="% de la venta registrada por producto",
                          yaxis=dict(tickformat=".0%", range=[0.6, 1]), legend=dict(orientation="h", y=-0.15))
        st.plotly_chart(fig, use_container_width=True)
    st.markdown(f"Octubre: **{int(ECO['Ventas_mes_TOBE']):,}** ventas, **{i2['TO_BE']:.1%}** registradas y "
                f"**{soles(ECO['No_reg_mes_TOBE'])}** sin registrar. La semana 1 fue la más baja por la adaptación; "
                "desde la semana 2 el registro supera el 93 %.")

# ================================================================ 5. ACTUAR
with t5:
    c = st.columns(6)
    kpi(c[0], "Beneficio anual", soles(ECO["Beneficio_anual"], 0), "Ingreso que deja de perderse")
    kpi(c[1], "Inversión inicial", soles(ECO["Inversion_inicial"]), "Materiales 5S + capacitación")
    kpi(c[2], "Costo operativo / año", soles(ECO["Costo_operativo_anual"]), "Cuadre, revisión, insumos")
    kpi(c[3], "B/C", f"{ECO['BC']:.2f}", "> 1: rentable")
    kpi(c[4], "ROI año 1", f"{ECO['ROI']:.0%}", "Beneficio neto / costo total")
    kpi(c[5], "Recuperación", f"{ECO['Recuperacion_meses']:.2f} meses", "Menos de medio mes")
    st.write("")
    a, b = st.columns(2)
    with a:
        fig = go.Figure(go.Waterfall(
            x=["No registrado al año (AS-IS)", "Beneficio de la mejora", "No registrado al año (TO-BE)"],
            measure=["absolute", "relative", "total"],
            y=[ECO["No_reg_anual_ASIS"], -ECO["Beneficio_anual"], 0],
            text=[soles(ECO["No_reg_anual_ASIS"], 0), "−" + soles(ECO["Beneficio_anual"], 0),
                  soles(ECO["No_reg_anual_TOBE"], 0)], textposition="outside",
            decreasing=dict(marker_color=VERDE), increasing=dict(marker_color=ROJO), totals=dict(marker_color=AZUL)))
        fig.update_layout(**PLOT, height=380, title="Ingreso no controlado al año: de dónde sale el beneficio")
        st.plotly_chart(fig, use_container_width=True)
    with b:
        g = INV.groupby("Etapa", as_index=False)["Total"].sum().sort_values("Total")
        fig = px.bar(g, x="Total", y="Etapa", orientation="h", text=[soles(v) for v in g["Total"]],
                     title=f"Inversión inicial por etapa 5S (total {soles(ECO['Inversion_inicial'])})")
        fig.update_traces(marker_color=DORADO, textposition="outside")
        fig.update_layout(**PLOT, height=380, xaxis_title=None, yaxis_title=None)
        st.plotly_chart(fig, use_container_width=True)
    st.markdown("""<div class="box"><b>Estandarizar:</b> código y lugar fijo para cada producto, regla “código en vitrina =
código en Excel”, formato único de registro y tablero con semáforo al cierre.<br>
<b>Corregir:</b> el IND 1 aún no llega al 80 %: reforzar la capacitación en horas pico y revisar cada semana los productos
que más salen “Sin código”.<br><b>Siguiente ciclo PHVA:</b> medir noviembre con datos reales y compararlo con octubre.</div>""",
                unsafe_allow_html=True)
    with st.expander("Ver detalle de la inversión"):
        st.dataframe(INV, hide_index=True, use_container_width=True)

st.caption("Fuente: Excel del Objetivo 3 (hoja Desarrollo de OBJ3). AS-IS = septiembre 2026 (datos del equipo); "
           "TO-BE = octubre 2026 simulado con la mejora. Meta: Araujo y Alva (2025), Universidad de Lima.")
