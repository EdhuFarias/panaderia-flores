@echo off
title Dashboard Objetivo 3 - Streamlit
cd /d "%~dp0"
set PY=
where python >nul 2>nul && set PY=python
if "%PY%"=="" ( where py >nul 2>nul && set PY=py )
if "%PY%"=="" (
  echo No se encontro Python. Instala Python desde https://www.python.org/downloads/ ^(marca "Add Python to PATH"^) y vuelve a abrir este archivo.
  pause
  exit /b
)
echo Usando %PY%
%PY% --version
echo Instalando paquetes (solo la primera vez tarda)...
%PY% -m pip install -r requirements.txt
echo Iniciando el dashboard en http://localhost:8501 ...
%PY% -m streamlit run app.py --server.headless true --server.port 8501
pause
