"""
PANADERÍA – OBJETIVO 3 | 5S + Gestión visual (codificación de los 9 productos)
Dashboard en Streamlit: AS-IS septiembre 2026 -> TO-BE octubre 2026 -> simulación de los meses siguientes.

Ejecutar en tu computadora:
    pip install -r requirements.txt
    streamlit run app.py

El archivo Datos_PowerBI_OBJ3.xlsx debe estar en la misma carpeta que app.py.
"""
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ---------------------------------------------------------------- configuración
st.set_page_config(page_title="Panadería · Objetivo 3 · 5S + Gestión visual", page_icon="🥖", layout="wide")
DATA = Path(__file__).parent / "Datos_PowerBI_OBJ3.xlsx"

ROJO, AZUL, VERDE, DORADO, GRIS, MORADO = "#F26B6B", "#3B82F6", "#34D399", "#FBBF24", "#9CA3AF", "#A78BFA"
PLOT = dict(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font=dict(family="Segoe UI, Roboto, sans-serif", size=12), margin=dict(l=10, r=10, t=45, b=10))
MESES_ES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre",
            "Noviembre", "Diciembre"]

st.markdown("""
<style>
.block-container {padding-top: 1.2rem;}
.hero {background: linear-gradient(90deg,#1e293b 0%,#334155 55%,#7c4a2d 100%); border:1px solid #475569;
       border-radius:14px; padding:22px 26px; margin-bottom:18px;}
.hero h1 {margin:0; font-size:2.0rem; color:#fff;}
.hero p {margin:4px 0 0 0; color:#cbd5e1;}
.kpi {background:#1e293b; border:1px solid #334155; border-radius:12px; padding:14px 16px; height:100%;}
.kpi .t {color:#94a3b8; font-size:.78rem; font-weight:600; text-transform:uppercase; letter-spacing:.4px;}
.kpi .v {color:#fff; font-size:1.8rem; font-weight:700; margin:2px 0;}
.kpi .s {color:#cbd5e1; font-size:.80rem;}
.ok {background:#064e3b; color:#6ee7b7; padding:2px 8px; border-radius:6px; font-size:.75rem; font-weight:700;}
.pr {background:#78350f; color:#fcd34d; padding:2px 8px; border-radius:6px; font-size:.75rem; font-weight:700;}
.bad {background:#7f1d1d; color:#fecaca; padding:2px 8px; border-radius:6px; font-size:.75rem; font-weight:700;}
.box {background:#1e293b; border:1px solid #334155; border-radius:12px; padding:14px 18px; margin-bottom:10px;}
.box b {color:#fbbf24;}
.prod {border-radius:10px; padding:12px; color:#111827; margin-bottom:10px; min-height:120px;}
.prod .c {font-size:1.3rem; font-weight:800;}
.small {color:#94a3b8; font-size:.8rem;}
</style>""", unsafe_allow_html=True)


# ---------------------------------------------------------------- datos
@st.cache_data
def cargar():
    return pd.read_excel(DATA, sheet_name=None)


try:
    D = cargar()
except FileNotFoundError:
    st.error("No encuentro 'Datos_PowerBI_OBJ3.xlsx'. Ponlo en la misma carpeta que app.py.")
    st.stop()

MEN, DIA, PROD, SEM = D["Mensual"], D["Diario"], D["Productos"], D["Semanal"]
IND = D["Indicadores"].set_index("Orden")
INV, CAP = D["Inversion"], D["Capacitacion"]
ECO = dict(zip(D["Economia"]["Concepto"], D["Economia"]["Valor"]))

HEX = {"Azul": "#BDD7EE", "Verde": "#C6EFCE", "Amarillo": "#FFEB9C", "Naranja": "#F8CBAD", "Morado": "#D9C3E9",
       "Rosado": "#F4CCCC", "Turquesa": "#B7E4E0", "Café": "#E2CBB0", "Gris": "#D9D9D9"}
PROD["Hex"] = PROD["Color"].map(HEX).fillna("#D9D9D9")
ANTES = {"CI-01": "En vitrina, mezclado y sin etiqueta", "FR-02": "En la misma canasta que el pan de yema",
         "EM-03": "Junto al pan, sin separación", "PY-04": "Tirado en la canasta del pan francés",
         "PI-05": "Bolsas sueltas sobre el mostrador", "CA-06": "Bandeja encima de la caja",
         "TO-07": "Bolsas tiradas sobre la harina", "PM-08": "Tiradas junto a las tostadas",
         "KE-09": "Táper abierto, sin precio"}
PLAN_5S = [
    ("SEIRI · Clasificar", "Semana 1", "11 tarjetas rojas (48 elementos retirados o reubicados); se recogen los 6 "
                                       "productos que estaban tirados."),
    ("SEITON · Ordenar", "Semanas 1–2", "Código, color y lugar fijo para los 9 productos: vitrina 1 (CI-01, FR-02, "
                                        "EM-03), vitrina 2 (PY-04, PI-05, CA-06), estante (TO-07, PM-08) y campana (KE-09)."),
    ("SEISO · Limpiar", "Semana 2", "Limpieza al abrir y cerrar; nada en el piso ni sobre la harina; etiquetas legibles."),
    ("SEIKETSU · Estandarizar", "Semana 3", "Regla 'código en vitrina = código en Excel' y un formato único de registro."),
    ("SHITSUKE · Disciplina", "Semana 4 en adelante", "9 capacitaciones, registrar al despachar, cuadre diario y "
                                                      "revisión semanal del orden."),
]

ASIS = DIA[DIA["Escenario"].str.startswith("AS-IS")].reset_index(drop=True)
TOBE = DIA[DIA["Escenario"].str.startswith("TO-BE")].reset_index(drop=True)
i1, i2, i3, i4 = IND.loc[1], IND.loc[2], IND.loc[3], IND.loc[4]
INVERSION = ECO["Inversion_inicial"]
OP_MES = ECO["Costo_operativo_anual"] / 12


def cumple(r, valor=None):
    v = r["TO_BE"] if valor is None else valor
    return v >= r["Meta"] if r["Mayor_es_mejor"] == "Sí" else v <= r["Meta"]


def kpi(col, titulo, valor, sub, ok=None):
    tag = "" if ok is None else (' <span class="ok">CUMPLE</span>' if ok else ' <span class="pr">EN PROCESO</span>')
    col.markdown(f'<div class="kpi"><div class="t">{titulo}</div><div class="v">{valor}</div>'
                 f'<div class="s">{sub}{tag}</div></div>', unsafe_allow_html=True)


def soles(x, d=2):
    return f"S/ {x:,.{d}f}"


def gauge(valor, meta, titulo, color):
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta", value=valor * 100, number={"suffix": "%", "valueformat": ".1f"},
        delta={"reference": meta * 100, "valueformat": ".1f", "suffix": " pp vs meta"},
        title={"text": titulo},
        gauge={"axis": {"range": [0, 100]}, "bar": {"color": color},
               "steps": [{"range": [0, meta * 100], "color": "#3f1d2b"}, {"range": [meta * 100, 100], "color": "#123b33"}],
               "threshold": {"line": {"color": "white", "width": 3}, "thickness": .85, "value": meta * 100}}))
    fig.update_layout(**PLOT, height=260)
    return fig


def semaforo(p):
    return "Verde" if p >= .8 else ("Amarillo" if p >= .6 else "Rojo")


# ---------------------------------------------------------------- barra lateral (menú + parámetros)
with st.sidebar:
    st.markdown("### 🥖 PANADERÍA")
    st.caption("Objetivo 3 · 5S + Gestión visual")
    st.divider()
    st.markdown("**📌 MENÚ**")
    pagina = st.radio("Sección", [
        "1️⃣ AS-IS · septiembre 2026", "2️⃣ Implementación 5S + gestión visual", "3️⃣ TO-BE · octubre 2026",
        "4️⃣ Simulación de los meses siguientes", "5️⃣ Evaluación económica", "🗂️ Datos"],
        label_visibility="collapsed")
    st.divider()
    st.markdown("**⚙️ PARÁMETROS DE SIMULACIÓN**")
    meses = st.slider("Meses a simular después de octubre", 1, 12, 6)
    cierre = st.slider("Cierre de brecha mensual", 0.05, 0.50, 0.251, 0.001, format="%.3f",
                       help="Parte de lo que falta que se mejora cada mes. 25.1 % = ritmo de Araujo y Alva (2025).")
    techo1 = st.slider("Techo IND 1 (% productos con código)", 0.70, 1.00, 0.95, 0.01,
                       help="Nivel máximo realista de uso de códigos.")
    techo2 = st.slider("Techo IND 2 (% ventas registradas)", 0.85, 1.00, 0.97, 0.01,
                       help="Nunca se registra el 100 %: siempre queda algún olvido.")
    crec = st.slider("Crecimiento de la demanda por mes", -0.05, 0.05, 0.01, 0.005, format="%.3f")
    ticket = st.slider("Ticket promedio por venta (S/)", 3.50, 6.00, float(round(ECO["Ticket_promedio"], 2)), 0.05)
    ruido = st.slider("Variación diaria del registro", 0.00, 0.08, 0.03, 0.005, format="%.3f",
                      help="Cuánto sube o baja el % registrado de un día a otro.")
    p_cero = st.slider("Probabilidad de un día sin registro", 0.00, 0.10, 0.02, 0.01)
    semilla = st.number_input("Semilla (cambia los datos simulados)", 0, 9999, 7, 1)
    st.caption("Mueve cualquier parámetro y la simulación, los gráficos y la evaluación económica se recalculan.")


# ---------------------------------------------------------------- simulación mensual (depende de los parámetros)
def simular():
    filas = [dict(n=0, Mes="Septiembre 2026", Etapa="AS-IS (real)", IND1=i1["AS_IS"], IND2=i2["AS_IS"],
                  Ventas_N=int(ECO["Ventas_mes_ASIS"]), Venta_S=ASIS["Venta_S"].sum()),
             dict(n=1, Mes="Octubre 2026", Etapa="TO-BE (con la mejora)", IND1=i1["TO_BE"], IND2=i2["TO_BE"],
                  Ventas_N=int(ECO["Ventas_mes_TOBE"]), Venta_S=TOBE["Venta_S"].sum())]
    p1, p2, n_v = i1["TO_BE"], i2["TO_BE"], ECO["Ventas_mes_TOBE"]
    mes, anio = 10, 2026
    for k in range(meses):
        mes += 1
        if mes > 12:
            mes, anio = 1, anio + 1
        p1 = p1 + cierre * max(techo1 - p1, 0)
        p2 = p2 + cierre * max(techo2 - p2, 0)
        n_v = n_v * (1 + crec)
        filas.append(dict(n=k + 2, Mes=f"{MESES_ES[mes]} {anio}", Etapa="Simulado", IND1=p1, IND2=p2,
                          Ventas_N=round(n_v), Venta_S=round(n_v) * ticket))
    df = pd.DataFrame(filas)
    df["No_registrado_S"] = df["Venta_S"] * (1 - df["IND2"])
    df["Beneficio_S"] = df["Venta_S"] * (df["IND2"] - i2["AS_IS"])  # ingreso que antes se perdía y ahora se registra
    df.loc[0, "Beneficio_S"] = 0.0
    df["Flujo_neto_S"] = df["Beneficio_S"] - np.where(df["n"] > 0, OP_MES, 0)
    df.loc[0, "Flujo_neto_S"] = -INVERSION
    df["Acumulado_S"] = df["Flujo_neto_S"].cumsum()
    df["IND1_cumple"] = df["IND1"] >= i1["Meta"]
    df["IND2_cumple"] = df["IND2"] >= i2["Meta"]
    return df


def simular_dias(fila, n_dias=30):
    rng = np.random.default_rng(int(semilla) * 100 + int(fila["n"]))
    base = fila["Venta_S"] / n_dias
    venta = np.maximum(base * (1 + rng.normal(0, 0.12, n_dias)), base * 0.5)
    pct = np.clip(rng.normal(fila["IND2"], ruido, n_dias), 0, 1)
    pct[rng.random(n_dias) < p_cero] = 0.0
    cod = np.clip(np.round(rng.normal(fila["IND1"] * 9, 0.8, n_dias)), 0, 9) / 9
    cod[pct == 0] = 0.0
    d = pd.DataFrame({"Día": range(1, n_dias + 1), "Venta (S/)": venta.round(1), "% registrado": pct,
                      "Registrado (S/)": (venta * pct).round(1), "% productos con código": cod})
    d["No registrado (S/)"] = d["Venta (S/)"] - d["Registrado (S/)"]
    d["Semáforo"] = d["% registrado"].apply(semaforo)
    return d


SIM = simular()

st.markdown('<div class="hero"><h1>🥖 PANADERÍA · OBJETIVO 3 · 5S + Gestión visual</h1>'
            '<p>Codificación de los 9 productos para registrar cada venta · AS-IS (septiembre 2026) → TO-BE '
            '(octubre 2026) → simulación de los meses siguientes</p></div>', unsafe_allow_html=True)

# ================================================================= 1. AS-IS
if pagina.startswith("1"):
    st.header("📉 Situación actual (AS-IS) · septiembre 2026")
    st.write("La panadería no anota sus ventas: el panadero las calcula “al ojo” al cierre. Los productos no tienen "
             "código ni lugar fijo.")
    c = st.columns(5)
    kpi(c[0], "IND 1 · % productos con código", f"{i1['AS_IS']:.0%}", "0 de 9 productos codificados")
    kpi(c[1], "IND 2 · % ventas registradas", f"{i2['AS_IS']:.1%}",
        f"{int(ECO['Ventas_mes_ASIS'] * i2['AS_IS']):,} de {int(ECO['Ventas_mes_ASIS']):,} ventas")
    kpi(c[2], "Ventas no registradas / mes", soles(i3["AS_IS"]), f"{int(ECO['Ventas_mes_ASIS'] * 0.18):,} ventas")
    kpi(c[3], "Días sin ningún registro", f"{int(i4['AS_IS'])}", "en el mes")
    kpi(c[4], "Ingreso no controlado / año", soles(ECO["No_reg_anual_ASIS"], 0), "si sigue igual")
    st.write("")
    a, b = st.columns(2)
    a.plotly_chart(gauge(i1["AS_IS"], i1["Meta"], "IND 1 · % productos con código", ROJO), use_container_width=True)
    b.plotly_chart(gauge(i2["AS_IS"], i2["Meta"], "IND 2 · % ventas registradas", ROJO), use_container_width=True)

    a, b = st.columns(2)
    with a:
        m = MEN.copy()
        m["Etiqueta"] = pd.to_datetime(m["Mes"]).dt.strftime("%b %y")
        fig = px.line(m, x="Etiqueta", y="Pct_registrado", markers=True, title="Problema general: 12 meses")
        fig.update_traces(line_color=AZUL)
        fig.add_scatter(x=[m["Etiqueta"].iloc[-1]], y=[m["Pct_registrado"].iloc[-1]], mode="markers+text",
                        marker=dict(size=14, color=ROJO), text=["AS-IS"], textposition="top center", showlegend=False)
        fig.update_layout(**PLOT, height=360, yaxis_tickformat=".0%", xaxis_title=None, yaxis_title="% registrado")
        st.plotly_chart(fig, use_container_width=True)
        tot = MEN["Ventas_registradas"].sum() / MEN["Ventas_realizadas"].sum()
        st.caption(f"En 12 meses se registró el {tot:.0%} de las ventas y se perdieron {soles(MEN['Perdida_S'].sum())}. "
                   "Septiembre es el último mes medido, por eso es el AS-IS.")
    with b:
        fig = px.bar(ASIS, x="Dia_mes", y="Pct_registrado", title="Septiembre: % registrado por día",
                     color=ASIS["Pct_registrado"].apply(semaforo),
                     color_discrete_map={"Verde": VERDE, "Amarillo": DORADO, "Rojo": ROJO})
        fig.update_layout(**PLOT, height=360, yaxis_tickformat=".0%", xaxis_title="Día del mes", yaxis_title=None,
                          legend_title="Semáforo", legend=dict(orientation="h", y=-0.2))
        st.plotly_chart(fig, use_container_width=True)
    st.subheader("¿Cómo estaban los productos?")
    st.dataframe(pd.DataFrame({"Producto": PROD["Producto"], "Situación antes": PROD["Codigo"].map(ANTES),
                               "¿Tenía código?": "No",
                               "Vendido sep (S/)": PROD["Venta_sep"].map(soles),
                               "Calculado al ojo (S/)": PROD["Registrado_sep"].map(soles),
                               "% registrado": (PROD["Registrado_sep"] / PROD["Venta_sep"]).map("{:.1%}".format)}),
                 hide_index=True, use_container_width=True)

# ================================================================= 2. IMPLEMENTACIÓN
elif pagina.startswith("2"):
    st.header("🧹 Implementación: 5S + gestión visual (4 semanas de octubre)")
    st.subheader("🏷️ Catálogo visual: código, color y lugar fijo")
    cols = st.columns(3)
    for k, r in PROD.iterrows():
        cols[k % 3].markdown(
            f'<div class="prod" style="background:{r["Hex"]}"><div class="c">{r["Codigo"]}</div>'
            f'<b>{r["Producto"]}</b> · S/ {r["Precio"]:.2f}<br>📍 {r["Ubicacion"]}<br>'
            f'<span style="font-size:.78rem">Antes: {ANTES.get(r["Codigo"], "")}</span></div>', unsafe_allow_html=True)
    a, b = st.columns([1.2, 1])
    with a:
        st.subheader("Plan por cada S")
        for s, cuando, que in PLAN_5S:
            st.markdown(f'<div class="box"><b>{s}</b> <span class="small">· {cuando}</span><br>{que}</div>',
                        unsafe_allow_html=True)
    with b:
        st.subheader("🚦 Tablero con semáforo (al cierre)")
        st.markdown('<div class="box">🟢 <b>VERDE</b>: ≥ 80 % registrado<br>🟡 <b>AMARILLO</b>: 60 % – 79 %<br>'
                    '🔴 <b>ROJO</b>: menos de 60 % → se anota la causa y se corrige al día siguiente</div>',
                    unsafe_allow_html=True)
        st.subheader("👨‍🍳 Capacitación del encargado")
        st.dataframe(CAP[["Semana", "Fecha", "Tema", "Minutos"]], hide_index=True, use_container_width=True)
        st.caption(f"Total: {CAP['Minutos'].sum():.0f} minutos ({CAP['Minutos'].sum() / 60:.1f} h) en 9 sesiones.")

# ================================================================= 3. TO-BE
elif pagina.startswith("3"):
    st.header("📈 Situación propuesta (TO-BE) · octubre 2026")
    st.write("Octubre con los 9 productos codificados, la lista de códigos en el Excel y el tablero con semáforo.")
    c = st.columns(5)
    kpi(c[0], "IND 1 · % productos con código", f"{i1['TO_BE']:.1%}",
        f"AS-IS {i1['AS_IS']:.0%} · Meta {i1['Meta']:.0%}", cumple(i1))
    kpi(c[1], "IND 2 · % ventas registradas", f"{i2['TO_BE']:.1%}",
        f"AS-IS {i2['AS_IS']:.1%} · Meta {i2['Meta']:.1%}", cumple(i2))
    kpi(c[2], "Ventas no registradas / mes", soles(i3["TO_BE"]),
        f"AS-IS {soles(i3['AS_IS'])} · Meta {soles(i3['Meta'])}", cumple(i3))
    kpi(c[3], "Días sin ningún registro", f"{int(i4['TO_BE'])}",
        f"AS-IS {int(i4['AS_IS'])} · Meta {int(i4['Meta'])}", cumple(i4))
    kpi(c[4], "Ingreso no controlado / año", soles(ECO["No_reg_anual_TOBE"], 0),
        f"AS-IS {soles(ECO['No_reg_anual_ASIS'], 0)}")
    st.write("")
    a, b = st.columns(2)
    a.plotly_chart(gauge(i1["TO_BE"], i1["Meta"], "IND 1 · % productos con código", DORADO), use_container_width=True)
    b.plotly_chart(gauge(i2["TO_BE"], i2["Meta"], "IND 2 · % ventas registradas", VERDE), use_container_width=True)
    st.caption(f"Progreso del IND 1 hacia su meta: {i1['TO_BE']:.1%} de {i1['Meta']:.0%}. Queda en proceso porque el "
               "encargado se está adaptando a los códigos (16 % la semana 1 → 81 % la última).")
    st.progress(min(i1["TO_BE"] / i1["Meta"], 1.0))

    a, b = st.columns(2)
    with a:
        fig = go.Figure()
        fig.add_scatter(x=ASIS["Dia_mes"], y=ASIS["Pct_registrado"], name="AS-IS (sep)", line_color=ROJO)
        fig.add_scatter(x=TOBE["Dia_mes"], y=TOBE["Pct_registrado"], name="TO-BE (oct)", line_color=VERDE)
        fig.add_hline(y=i2["Meta"], line_dash="dot", line_color=DORADO, annotation_text=f"Meta {i2['Meta']:.1%}")
        fig.update_layout(**PLOT, height=360, title="% de ventas registradas por día: AS-IS vs. TO-BE",
                          yaxis_tickformat=".0%", xaxis_title="Día del mes", legend=dict(orientation="h", y=-0.2))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        fig = go.Figure()
        fig.add_bar(x=SEM["Semana"], y=SEM["Pct_registrado"], name="% ventas registradas", marker_color=AZUL,
                    text=[f"{v:.0%}" for v in SEM["Pct_registrado"]], textposition="outside")
        fig.add_bar(x=SEM["Semana"], y=SEM["Pct_uso_codigos"], name="% productos con código", marker_color=DORADO,
                    text=[f"{v:.0%}" for v in SEM["Pct_uso_codigos"]], textposition="outside")
        fig.update_layout(**PLOT, height=360, barmode="group", title="Curva de adaptación del encargado",
                          yaxis=dict(tickformat=".0%", range=[0, 1.15]), legend=dict(orientation="h", y=-0.2))
        st.plotly_chart(fig, use_container_width=True)
    a, b = st.columns(2)
    with a:
        p = PROD.sort_values("Pct_uso_codigo_oct")
        fig = go.Figure(go.Bar(x=p["Pct_uso_codigo_oct"], y=p["Codigo"] + " " + p["Producto"], orientation="h",
                               marker_color=p["Hex"], marker_line=dict(color="#111827", width=1),
                               text=[f"{v:.0%}" for v in p["Pct_uso_codigo_oct"]], textposition="outside"))
        fig.add_vline(x=i1["Meta"], line_dash="dot", line_color=DORADO, annotation_text="Meta 80 %")
        fig.update_layout(**PLOT, height=400, title="% de días en que cada producto se anotó con su código",
                          xaxis=dict(tickformat=".0%", range=[0, 1.05]))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        cnt = TOBE["Pct_registrado"].apply(semaforo).value_counts().reindex(["Verde", "Amarillo", "Rojo"]).fillna(0)
        fig = px.pie(values=cnt.values, names=cnt.index, hole=.55, color=cnt.index,
                     color_discrete_map={"Verde": VERDE, "Amarillo": DORADO, "Rojo": ROJO},
                     title="Días de octubre según el semáforo del tablero")
        fig.update_layout(**PLOT, height=400)
        st.plotly_chart(fig, use_container_width=True)

# ================================================================= 4. SIMULACIÓN
elif pagina.startswith("4"):
    st.header("📅 Simulación de los meses siguientes")
    ultimo = SIM.iloc[-1]
    st.write(f"Septiembre = AS-IS real · Octubre = TO-BE · **{SIM.iloc[2]['Mes']} a {ultimo['Mes']} = simulados**: "
             f"cada mes se cierra el **{cierre:.1%}** de lo que falta para llegar al techo "
             f"(IND 1 {techo1:.0%}, IND 2 {techo2:.0%}); la demanda cambia {crec:+.1%} por mes y el ticket es "
             f"{soles(ticket)}. Cambia los parámetros en la barra lateral.")
    meta1 = SIM[SIM["IND1_cumple"]]
    c = st.columns(4)
    kpi(c[0], f"IND 1 en {ultimo['Mes']}", f"{ultimo['IND1']:.1%}", f"Octubre {i1['TO_BE']:.1%} · Meta 80 %",
        bool(ultimo["IND1_cumple"]))
    kpi(c[1], f"IND 2 en {ultimo['Mes']}", f"{ultimo['IND2']:.1%}", f"Octubre {i2['TO_BE']:.1%} · Meta {i2['Meta']:.1%}",
        bool(ultimo["IND2_cumple"]))
    kpi(c[2], "IND 1 llega a la meta en", meta1.iloc[0]["Mes"] if len(meta1) else "No llega",
        "con el ritmo elegido")
    kpi(c[3], f"No registrado en {ultimo['Mes']}", soles(ultimo["No_registrado_S"]),
        f"AS-IS {soles(i3['AS_IS'])}")
    st.write("")
    fig = go.Figure()
    fig.add_scatter(x=SIM["Mes"], y=SIM["IND1"], name="IND 1 · % productos con código", mode="lines+markers+text",
                    text=[f"{v:.0%}" for v in SIM["IND1"]], textposition="bottom center", line=dict(color=DORADO, width=3))
    fig.add_scatter(x=SIM["Mes"], y=SIM["IND2"], name="IND 2 · % ventas registradas", mode="lines+markers+text",
                    text=[f"{v:.0%}" for v in SIM["IND2"]], textposition="top center", line=dict(color=VERDE, width=3))
    fig.add_hline(y=i1["Meta"], line_dash="dot", line_color=DORADO, annotation_text="Meta IND 1")
    fig.add_hline(y=i2["Meta"], line_dash="dot", line_color=VERDE, annotation_text="Meta IND 2",
                  annotation_position="bottom right")
    fig.add_vrect(x0=1.5, x1=len(SIM) - 0.5, fillcolor=MORADO, opacity=0.08, line_width=0,
                  annotation_text="Simulado", annotation_position="top left")
    fig.update_layout(**PLOT, height=420, yaxis_tickformat=".0%", yaxis_range=[0, 1.08],
                      title="Evolución de los indicadores", legend=dict(orientation="h", y=-0.2))
    st.plotly_chart(fig, use_container_width=True)

    a, b = st.columns(2)
    with a:
        fig = go.Figure()
        fig.add_bar(x=SIM["Mes"], y=SIM["No_registrado_S"], name="Ventas no registradas (S/)",
                    marker_color=[ROJO, VERDE] + [MORADO] * meses,
                    text=[soles(v, 0) for v in SIM["No_registrado_S"]], textposition="outside")
        fig.update_layout(**PLOT, height=380, title="Ventas no registradas por mes (S/)")
        st.plotly_chart(fig, use_container_width=True)
    with b:
        vista = SIM[["Mes", "Etapa", "IND1", "IND2", "Ventas_N", "Venta_S", "No_registrado_S", "Beneficio_S"]].copy()
        vista.columns = ["Mes", "Etapa", "IND 1", "IND 2", "N° ventas", "Venta (S/)", "No registrado (S/)",
                         "Beneficio vs AS-IS (S/)"]
        for col in ["IND 1", "IND 2"]:
            vista[col] = vista[col].map("{:.1%}".format)
        for col in ["Venta (S/)", "No registrado (S/)", "Beneficio vs AS-IS (S/)"]:
            vista[col] = vista[col].map(lambda v: soles(v, 0))
        st.dataframe(vista, hide_index=True, use_container_width=True, height=380)

    st.subheader("🔍 Detalle diario de un mes simulado")
    elegido = st.selectbox("Elige el mes", SIM["Mes"].iloc[2:].tolist())
    fila = SIM[SIM["Mes"] == elegido].iloc[0]
    dd = simular_dias(fila)
    c = st.columns(4)
    kpi(c[0], "% registrado del mes", f"{dd['Registrado (S/)'].sum() / dd['Venta (S/)'].sum():.1%}", elegido)
    kpi(c[1], "% productos con código", f"{dd['% productos con código'].mean():.1%}", "promedio diario")
    kpi(c[2], "Días en verde", f"{(dd['Semáforo'] == 'Verde').sum()} de 30",
        f"Rojo: {(dd['Semáforo'] == 'Rojo').sum()}")
    kpi(c[3], "Días sin registro", f"{(dd['% registrado'] == 0).sum()}", f"Prob. {p_cero:.0%} por día")
    fig = px.bar(dd, x="Día", y="% registrado", color="Semáforo",
                 color_discrete_map={"Verde": VERDE, "Amarillo": DORADO, "Rojo": ROJO},
                 title=f"{elegido}: % registrado por día (cambia la semilla para otra simulación)")
    fig.add_hline(y=i2["Meta"], line_dash="dot", line_color=DORADO)
    fig.update_layout(**PLOT, height=340, yaxis_tickformat=".0%", legend=dict(orientation="h", y=-0.25))
    st.plotly_chart(fig, use_container_width=True)
    with st.expander("Ver la tabla diaria simulada"):
        st.dataframe(dd.style.format({"% registrado": "{:.1%}", "% productos con código": "{:.0%}",
                                      "Venta (S/)": "S/ {:,.1f}", "Registrado (S/)": "S/ {:,.1f}",
                                      "No registrado (S/)": "S/ {:,.1f}"}), hide_index=True, use_container_width=True)

# ================================================================= 5. ECONÓMICO
elif pagina.startswith("5"):
    st.header("💰 Evaluación económica")
    st.markdown("**Según el Excel (año 1, con octubre como mes típico)**")
    c = st.columns(6)
    kpi(c[0], "Beneficio anual", soles(ECO["Beneficio_anual"], 0), "Ingreso que deja de perderse")
    kpi(c[1], "Inversión inicial", soles(INVERSION), "Materiales 5S + capacitación")
    kpi(c[2], "Costo operativo / año", soles(ECO["Costo_operativo_anual"]), "Cuadre, revisión, insumos")
    kpi(c[3], "B/C", f"{ECO['BC']:.2f}", "> 1: rentable", ECO["BC"] > 1)
    kpi(c[4], "ROI año 1", f"{ECO['ROI']:.0%}", "Beneficio neto / costo total")
    kpi(c[5], "Recuperación", f"{ECO['Recuperacion_meses']:.2f} meses", "Inversión / beneficio neto mensual")
    st.write("")
    st.markdown("**Según la simulación (cambia con los parámetros)**")
    cok_a = st.slider("Costo de oportunidad (COK) anual", 0.05, 0.30, 0.15, 0.01)
    cok_m = (1 + cok_a) ** (1 / 12) - 1
    fl = SIM["Flujo_neto_S"].tolist()
    t = SIM["n"].tolist()
    van = sum(f / (1 + cok_m) ** k for k, f in zip(t, fl))
    vp_b = sum(b / (1 + cok_m) ** k for k, b in zip(t[1:], SIM["Beneficio_S"].tolist()[1:]))
    vp_c = INVERSION + sum(OP_MES / (1 + cok_m) ** k for k in t[1:])
    rec = SIM[SIM["Acumulado_S"] >= 0]
    c = st.columns(4)
    kpi(c[0], f"VAN ({len(SIM) - 1} meses)", soles(van, 0), f"COK {cok_a:.0%} anual", van > 0)
    kpi(c[1], "B/C simulado", f"{vp_b / vp_c:.2f}", "> 1 es rentable", vp_b / vp_c > 1)
    kpi(c[2], "Beneficio acumulado", soles(SIM["Acumulado_S"].iloc[-1], 0), f"a {SIM['Mes'].iloc[-1]}")
    kpi(c[3], "Se recupera en", rec.iloc[0]["Mes"] if len(rec) else "No se recupera", "flujo acumulado ≥ 0")
    st.write("")
    a, b = st.columns(2)
    with a:
        fig = go.Figure()
        fig.add_bar(x=SIM["Mes"], y=SIM["Flujo_neto_S"], name="Flujo neto del mes",
                    marker_color=[ROJO] + [AZUL] * (len(SIM) - 1))
        fig.add_scatter(x=SIM["Mes"], y=SIM["Acumulado_S"], name="Flujo acumulado", line=dict(color=VERDE, width=3))
        fig.add_hline(y=0, line_color=GRIS)
        fig.update_layout(**PLOT, height=400, title="Flujo de caja (S/)", legend=dict(orientation="h", y=-0.25))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        g = INV.groupby("Etapa", as_index=False)["Total"].sum().sort_values("Total")
        fig = px.bar(g, x="Total", y="Etapa", orientation="h", text=[soles(v) for v in g["Total"]],
                     title=f"Inversión inicial por etapa 5S (total {soles(INVERSION)})")
        fig.update_traces(marker_color=DORADO, textposition="outside")
        fig.update_layout(**PLOT, height=400, xaxis_title=None, yaxis_title=None)
        st.plotly_chart(fig, use_container_width=True)
    st.caption("Beneficio del mes = venta del mes × (% registrado del mes − 82 % del AS-IS): es el ingreso que antes "
               f"se perdía y ahora queda registrado. Costo operativo mensual = {soles(OP_MES)}.")

# ================================================================= DATOS
else:
    st.header("🗂️ Datos y descargas")
    for nombre, df in D.items():
        with st.expander(nombre):
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.download_button(f"Descargar {nombre}.csv", df.to_csv(index=False).encode("utf-8-sig"),
                               f"{nombre}.csv", "text/csv", key=nombre)
    st.download_button("Descargar simulación mensual.csv", SIM.to_csv(index=False).encode("utf-8-sig"),
                       "Simulacion_mensual.csv", "text/csv")

st.markdown("---")
st.caption("Fuente: Excel del Objetivo 3. AS-IS = septiembre 2026 (datos del equipo); TO-BE = octubre 2026 simulado con "
           "la mejora; noviembre en adelante = simulación con los parámetros de la barra lateral. Metas: Araujo y Alva "
           "(2025), Universidad de Lima.")
